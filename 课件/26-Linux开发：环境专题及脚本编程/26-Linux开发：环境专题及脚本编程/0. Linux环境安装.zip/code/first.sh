#!/bin/bash
#echo "Hello World"

#zerovoice="www.0voice.com"
#echo $zerovoice

for file in $(ls /home/wangbojing/share/); do
	echo "${file}"
done
